export default function Divider({ text = "or" }: { text?: string }) {
  return (
    <div className="flex items-center w-full">
      <div className="flex-grow h-[1px] bg-[#444]" />
      <span className="px-3 text-sm text-white font-semibold text-[20px]">{text}</span>
      <div className="flex-grow h-[1px] bg-[#444]" />
    </div>
  );
}
