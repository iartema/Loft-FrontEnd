import { Akatab } from "next/font/google";
const akatab = Akatab({ subsets: ["latin"], weight: ["400", "500"] });

type InputProps = React.InputHTMLAttributes<HTMLInputElement>

export default function Input(props: InputProps) {
  return (
    <input
      {...props}
      className={`${akatab.className} w-full bg-[#2D2D30] rounded-full px-5 py-3 outline-none text-[20px] ${props.className ?? ""}`}
    />
  );
}
